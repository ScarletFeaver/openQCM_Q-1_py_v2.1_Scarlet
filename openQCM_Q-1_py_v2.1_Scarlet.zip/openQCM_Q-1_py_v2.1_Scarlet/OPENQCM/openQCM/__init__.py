from openQCM.core.constants import Constants


__version__ = Constants.app_version

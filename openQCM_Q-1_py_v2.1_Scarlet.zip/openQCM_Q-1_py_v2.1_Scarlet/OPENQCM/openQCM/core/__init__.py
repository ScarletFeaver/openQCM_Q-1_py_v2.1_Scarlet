"""
Application specific implementations.
"""
"""
UI related scripts.
"""
"""
Wrappers and methods for general or common tasks.
"""
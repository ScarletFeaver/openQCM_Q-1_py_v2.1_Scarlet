from openQCM.core.constants import Constants

TAG = "[Switcher]"

###############################################################################
# Switches from overtone frequency to frequency range for 10MHz QC Sensor
# Returns other parameters that are used for processing
###############################################################################
class Overtone_Switcher_10MHz:
    
    def __init__(self,peak_frequencies = None):
        self.peak_frequencies = peak_frequencies
    
    # from fundamental frequency to the 5th overtone  
    def overtone10MHz_to_freq_range(self, argument):
        method_name = 'overtone_' + str(argument)
        # Get the method from 'self'. Default to a lambda.
        method = getattr(self, method_name, lambda: None)
        # Call the method as we return it
        return method()
 
    def overtone_0(self):
        # fundamental frequency
        name = "fundamental"
        start = self.peak_frequencies[0] - Constants.L10_fundamental
        stop  = self.peak_frequencies[0] + Constants.R10_fundamental
        return name ,self.peak_frequencies[0], start, stop, Constants.SG_window_size10_fundamental, Constants.Spline_factor10_fundamental
 
    def overtone_1(self):
        # 3th Overtone
        name = "3th Overtone"
        start = self.peak_frequencies[1] - Constants.L10_3th_overtone
        stop  = self.peak_frequencies[1] + Constants.R10_3th_overtone
        return name, self.peak_frequencies[1], start, stop, Constants.SG_window_size10_3th_overtone, Constants.Spline_factor10_3th_overtone
    
    def overtone_2(self):
        # 5th Overtone
        name = "5th Overtone"
        start = self.peak_frequencies[2] - Constants.L10_5th_overtone
        stop  = self.peak_frequencies[2] + Constants.R10_5th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size10_5th_overtone, Constants.Spline_factor10_5th_overtone


###############################################################################
# Switches from overtone frequency to frequency range for 8MHz QC Sensor
###############################################################################
class Overtone_Switcher_8MHz:
    
    def __init__(self,peak_frequencies = None):
        self.peak_frequencies = peak_frequencies
    
    # from fundamental frequency to the 5th overtone  
    def overtone8MHz_to_freq_range(self, argument):
        method_name = 'overtone_' + str(argument)
        # Get the method from 'self'. Default to a lambda.
        method = getattr(self, method_name, lambda: None)
        # Call the method as we return it
        return method()
 
    def overtone_0(self):
        # fundamental frequency
        name = "fundamental"
        start = self.peak_frequencies[0] - Constants.L8_fundamental
        stop  = self.peak_frequencies[0] + Constants.R8_fundamental
        return name ,self.peak_frequencies[0], start, stop, Constants.SG_window_size8_fundamental, Constants.Spline_factor8_fundamental
 
    def overtone_1(self):
        # 3th Overtone
        name = "3th Overtone"
        start = self.peak_frequencies[1] - Constants.L8_3th_overtone
        stop  = self.peak_frequencies[1] + Constants.R8_3th_overtone
        return name, self.peak_frequencies[1], start, stop, Constants.SG_window_size8_3th_overtone, Constants.Spline_factor8_3th_overtone
    
    def overtone_2(self):
        # 5th Overtone
        name = "5th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_5th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_5th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_5th_overtone, Constants.Spline_factor8_5th_overtone
    
    def overtone_3(self):
        # 5th Overtone
        name = "7th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_7th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_7th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_7th_overtone, Constants.Spline_factor8_7th_overtone

    def overtone_4(self):
        # 5th Overtone
        name = "9th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_9th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_9th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_9th_overtone, Constants.Spline_factor8_9th_overtone

    def overtone_5(self):
        # 5th Overtone
        name = "11th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_11th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_11th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_11th_overtone, Constants.Spline_factor8_11th_overtone
    
    def overtone_6(self):
        # 5th Overtone
        name = "13th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_13th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_13th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_13th_overtone, Constants.Spline_factor8_13th_overtone 

    def overtone_7(self):
        # 5th Overtone
        name = "15th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_15th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_15th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_15th_overtone, Constants.Spline_factor8_15th_overtone

    def overtone_8(self):
        # 5th Overtone
        name = "17th Overtone"
        start = self.peak_frequencies[2] - Constants.L8_17th_overtone
        stop  = self.peak_frequencies[2] + Constants.R8_17th_overtone
        return name, self.peak_frequencies[2], start, stop, Constants.SG_window_size8_17th_overtone, Constants.Spline_factor8_17th_overtone
    
    
###############################################################################
# Switches from overtone frequency to frequency range for 5MHz QC Sensor
###############################################################################
class Overtone_Switcher_5MHz:
    
    def __init__(self,peak_frequencies = None):
        self.peak_frequencies = peak_frequencies
    
    # from fundamental frequency to the 9th overtone    
    def overtone5MHz_to_freq_range(self, argument):
        method_name = 'overtone_' + str(argument)
        # Get the method from 'self'. Default to a lambda.
        method = getattr(self, method_name, lambda: None)
        # Call the method as we return it
        return method()
 
    def overtone_0(self):
        # fundamental frequency
        name = "fundamental"
        start = self.peak_frequencies[0] - Constants.L5_fundamental
        stop  = self.peak_frequencies[0] + Constants.R5_fundamental
        return name, self.peak_frequencies[0], start, stop, Constants.SG_window_size5_fundamental, Constants.Spline_factor5_fundamental
 
    def overtone_1(self):
        # 3th Overtone
        name = "3th Overtone"
        start = self.peak_frequencies[1] - Constants.L5_3th_overtone
        stop  = self.peak_frequencies[1] + Constants.R5_3th_overtone
        return name, self.peak_frequencies[1], start, stop, Constants.SG_window_size5_3th_overtone, Constants.Spline_factor5_3th_overtone
    
    def overtone_2(self):
        # 5th Overtone
        name = "5th Overtone"
        start = self.peak_frequencies[2] - Constants.L5_5th_overtone
        stop  = self.peak_frequencies[2] + Constants.R5_5th_overtone
        return name, self.peak_frequencies[2],start,stop, Constants.SG_window_size5_5th_overtone, Constants.Spline_factor5_5th_overtone

    def overtone_3(self):
        # 7th Overtone
        name = "7th Overtone"
        start = self.peak_frequencies[3] - Constants.L5_7th_overtone
        stop  = self.peak_frequencies[3] + Constants.R5_7th_overtone
        return name, self.peak_frequencies[3],start,stop, Constants.SG_window_size5_7th_overtone, Constants.Spline_factor5_7th_overtone

    def overtone_4(self):
        # 9th Overtone
        name = "9th Overtone"
        start = self.peak_frequencies[4] - Constants.L5_9th_overtone
        stop  = self.peak_frequencies[4] + Constants.R5_9th_overtone
        return name, self.peak_frequencies[4], start, stop, Constants.SG_window_size5_9th_overtone, Constants.Spline_factor5_9th_overtone

###############################################################################
# Switches from overtone frequency to frequency range for 6MHz QC Sensor
###############################################################################
class Overtone_Switcher_6MHz:
    
    def __init__(self,peak_frequencies = None):
        self.peak_frequencies = peak_frequencies
    
    # from fundamental frequency to the 9th overtone    
    def overtone6MHz_to_freq_range(self, argument):
        method_name = 'overtone_' + str(argument)
        # Get the method from 'self'. Default to a lambda.
        method = getattr(self, method_name, lambda: None)
        # Call the method as we return it
        return method()
 
    def overtone_0(self):
        # fundamental frequency
        name = "fundamental"
        start = self.peak_frequencies[0] - Constants.L6_fundamental
        stop  = self.peak_frequencies[0] + Constants.R6_fundamental
        return name, self.peak_frequencies[0], start, stop, Constants.SG_window_size6_fundamental, Constants.Spline_factor6_fundamental
 
    def overtone_1(self):
        # 3th Overtone
        name = "3th Overtone"
        start = self.peak_frequencies[1] - Constants.L6_3th_overtone
        stop  = self.peak_frequencies[1] + Constants.R6_3th_overtone
        return name, self.peak_frequencies[1], start, stop, Constants.SG_window_size6_3th_overtone, Constants.Spline_factor6_3th_overtone
    
    def overtone_2(self):
        # 5th Overtone
        name = "5th Overtone"
        start = self.peak_frequencies[2] - Constants.L6_5th_overtone
        stop  = self.peak_frequencies[2] + Constants.R6_5th_overtone
        return name, self.peak_frequencies[2],start,stop, Constants.SG_window_size6_5th_overtone, Constants.Spline_factor6_5th_overtone

    def overtone_3(self):
        # 7th Overtone
        name = "7th Overtone"
        start = self.peak_frequencies[3] - Constants.L6_7th_overtone
        stop  = self.peak_frequencies[3] + Constants.R6_7th_overtone
        return name, self.peak_frequencies[3],start,stop, Constants.SG_window_size6_7th_overtone, Constants.Spline_factor6_7th_overtone

    def overtone_4(self):
        # 9th Overtone
        name = "9th Overtone"
        start = self.peak_frequencies[4] - Constants.L6_9th_overtone
        stop  = self.peak_frequencies[4] + Constants.R6_9th_overtone
        return name, self.peak_frequencies[4], start, stop, Constants.SG_window_size6_9th_overtone, Constants.Spline_factor6_9th_overtone
 
###############################################################################
# Switches from overtone frequency to frequency range for 3MHz QC Sensor
###############################################################################
class Overtone_Switcher_3MHz:
    
    def __init__(self,peak_frequencies = None):
        self.peak_frequencies = peak_frequencies
    
    # from fundamental frequency to the 9th overtone    
    def overtone3MHz_to_freq_range(self, argument):
        method_name = 'overtone_' + str(argument)
        # Get the method from 'self'. Default to a lambda.
        method = getattr(self, method_name, lambda: None)
        # Call the method as we return it
        return method()
 
    def overtone_0(self):
        # fundamental frequency
        name = "fundamental"
        start = self.peak_frequencies[0] - Constants.L3_fundamental
        stop  = self.peak_frequencies[0] + Constants.R3_fundamental
        return name, self.peak_frequencies[0], start, stop, Constants.SG_window_size3_fundamental, Constants.Spline_factor3_fundamental
 
    def overtone_1(self):
        # 3th Overtone
        name = "3th Overtone"
        start = self.peak_frequencies[1] - Constants.L3_3th_overtone
        stop  = self.peak_frequencies[1] + Constants.R3_3th_overtone
        return name, self.peak_frequencies[1], start, stop, Constants.SG_window_size3_3th_overtone, Constants.Spline_factor3_3th_overtone
    
    def overtone_2(self):
        # 5th Overtone
        name = "5th Overtone"
        start = self.peak_frequencies[2] - Constants.L3_5th_overtone
        stop  = self.peak_frequencies[2] + Constants.R3_5th_overtone
        return name, self.peak_frequencies[2],start,stop, Constants.SG_window_size3_5th_overtone, Constants.Spline_factor3_5th_overtone

    def overtone_3(self):
        # 7th Overtone
        name = "7th Overtone"
        start = self.peak_frequencies[3] - Constants.L3_7th_overtone
        stop  = self.peak_frequencies[3] + Constants.R3_7th_overtone
        return name, self.peak_frequencies[3],start,stop, Constants.SG_window_size3_7th_overtone, Constants.Spline_factor3_7th_overtone

    def overtone_4(self):
        # 9th Overtone
        name = "9th Overtone"
        start = self.peak_frequencies[4] - Constants.L3_9th_overtone
        stop  = self.peak_frequencies[4] + Constants.R3_9th_overtone
        return name, self.peak_frequencies[4], start, stop, Constants.SG_window_size3_9th_overtone, Constants.Spline_factor3_9th_overtone
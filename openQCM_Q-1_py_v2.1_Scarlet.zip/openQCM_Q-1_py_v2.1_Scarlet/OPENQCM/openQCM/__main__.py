from openQCM.app import OPENQCM


if __name__ == '__main__':
    OPENQCM().run()

#!/usr/bin/env python
# coding: utf-8

# In[8]:


import os
import pandas as pd # must be installed before use, "pip install wheel" & "pip install pandas" into anaconda prompt 
import natsort # must be installed before use, type "conda install -c anaconda natsort" into the anaconda prompt
from tqdm import tqdm

'''
There must be no other numbers in the File name!!!
'''

'''
Define a function to acquire the frequency column of the first file in the datafolder which is specified after. 
This is only defining the function, it is called upon much later, once a folder has been selected by the user.
'''
def freqcol(folder):
    '''
    Creates the frequency column of the csv folder from the first file
    '''
    
    '''
    adds the frequency values to this data table - takes this data from the first sweep
    '''
    freq = os.listdir(folder)[0]   #takes the first file of the folder
    freq = pd.read_csv(f'{folder}/{freq}', delimiter = ' ', header = None, names = [" "], usecols = [0]) #creates data table of this data
    return freq


'''
first ask user where data comes from?
'''
print("What folder is your data in?", "\n", \
	r" e.g. C:\\Users\\YOURNAME\\Documents\\Folder1\\Folder2\\~Data~\\YYYY-MM-DD_HH-MM-SS_sweepdata", "\n", \
	"\n", "There can only be one number, the sweep number, in the file name", "\n", flush = True)

DataFolder = input("Copy the address of the sweep data folder and press ENTER") #allows user to input their desired folder
print("\n", "Your chosen data folder is {0}".format(DataFolder), "\n", flush = True) #confirms to user their chosen folder
DataFolder = DataFolder.replace('"','') #converts the inputted folder into a useable format

'''
Checks if the amplitude, phase or both csv files already exist as this will disrupt the programme. If the files have been renamed then this will fail.
Thus, programme checks for them before generating any new files.
'''
if os.path.isfile(f'{DataFolder}\\FullSweepData_Amplitude.csv') and os.path.isfile(f'{DataFolder}\\FullSweepData_Phase.csv'): #checks for both csv files
    print("Combined amplitude and phase data has already been created for this sweep folder. ", "\n", \
    	"Please check you have inputted the correct sweep folder. ", "\n", \
    	"If this was intentional and you wish to make them again ", \
    	"please move these csv files to a new location or delete them and restart the programme.")
elif os.path.isfile(f'{DataFolder}\\FullSweepData_Amplitude.csv'): #checks for amplitude csv file
    print("\n", "Combined amplitude data has already been created for this sweep folder but not phase data", \
    	"\n", "This existance of the former prevents the latter from being made so ", \
    	"please move the" , '\033[1m' + "amplitude" + '\033[0m', \
    	"data to another folder or delete it so that both can be created together")
elif os.path.isfile(f'{DataFolder}\\FullSweepData_Phase.csv'): #checks for phase csv file
    print("\n", "Combined phase data has already been created for this sweep folder but not amplitude data.", \
    	"\n", "This existance of the former prevents the latter from being made so ", \
    	"please move the", '\033[1m' + "phase" + '\033[0m', \
    	"data to another folder or delete it so that both can be created together")
else: #If the csv files do not already exist then the programme will generate them
	'''
	Firstly generates data table for Amplitude data
	'''
	count = 0                       #creates a count to keep track of the sweep number
	amp = freqcol(DataFolder)       #generates a data file with f values for amplitude data
	for file in tqdm(natsort.natsorted(os.listdir(DataFolder)), desc = "Converting amplitude data"):     #iterate over all files in the folder
		filename = f'{DataFolder}/{file}' #generates the full file name
		sweepx = pd.read_csv(filename, delimiter = ' ', header = None, usecols = [1], low_memory=False) #reads amp data of file
		amp["{0}".format(count)] = sweepx #appends this to the generated data frame
		count = count + 1           #ensures the next sweep number is consistent

	'''
	Then generates data table for Phase data
	'''
	count = 0
	phase = freqcol(DataFolder)       #generates a new data file with f values for phase data
	for file in tqdm(natsort.natsorted(os.listdir(DataFolder)), desc = "Converting phase data    "): #iterates over all files in the folder
		filename = f'{DataFolder}/{file}' #generates full file name
		sweepx = pd.read_csv(filename, delimiter = ' ', header = None, usecols = [2], low_memory=False) #reads phase data in file
		phase["{0}".format(count)] = sweepx #appends this to the generated data frame
		count = count + 1             #ensures next sweep number is consistent
	'''
	Converts data tables into a csv format with the file names shown in red below
	'''
	amp.to_csv(f'{DataFolder}\\FullSweepData_Amplitude.csv',index = None, encoding = "utf-8-sig") #generates amplitude csv
	print("\n", "Succesfully created Amplitude csv file in {0}".format(DataFolder)) #assures user that amplitude file has been succesfully created
	phase.to_csv(f'{DataFolder}\\FullSweepData_Phase.csv',index = None, encoding = "utf-8-sig")   #generates phase csv
	print(" Succesfully created Phase csv file in {0}".format(DataFolder)) #assures user that phase file has been succesfully created


# In[ ]:




